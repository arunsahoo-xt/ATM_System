  
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.atm;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.util.*;

public class notepad extends javax.swing.JFrame {
   
    File C = new File("C:\\ATM files\\LOGIN DATA");
    int ln,ran,ans;
    String Username,Password,Email;
    static String acc="",acno="",bal="",prevbal="",change="",firstname="",lastname="";
    /**
     * Creates new form notepad
     */
    public notepad() {
        initComponents();
    }

    void createFolder(){
        if(!C.exists()){
            C.mkdirs();
        }
    }
    public String random(String rndm){
       
        Random rand=new Random();
        for(int i=0;i<12;i++){
            ran=rand.nextInt(10);
            rndm=rndm+ran;
        }
        return rndm;
    }
    
    void readFile(){
        try {
            FileReader fr = new FileReader(C+"\\logins.txt");
            System.out.println("file exists!");
        } catch (FileNotFoundException ex) {
            try {
                FileWriter fw = new FileWriter(C+"\\logins.txt");
                System.out.println("File created");
            } catch (IOException ex1) {
                Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex1);
            }
        }
        
    }
    
    void addData(String first,String last,String usr,String pswd,String mail){
         String rndm="",a="";
        try {
            RandomAccessFile raf = new RandomAccessFile(C+"\\logins.txt", "rw");
            for(int i=0;i<ln;i++){
                raf.readLine();
            }
            //if condition added after video to have no lines on first entry
            if(ln>0){
            raf.writeBytes("\r\n");
            raf.writeBytes("\r\n");
            }
            a=random(rndm);
            raf.writeBytes("First Name:"+first+ "\r\n");
            raf.writeBytes("Last Name:"+last+ "\r\n");
            raf.writeBytes("Username:"+usr+ "\r\n");
            raf.writeBytes("Password:"+pswd+ "\r\n");
            raf.writeBytes("Account No.:"+a+"\r\n");
            raf.writeBytes("Initial Balance:"+mail);
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    void logic(String usr,String pswd){
        boolean q=false;
        try {
            RandomAccessFile raf = new RandomAccessFile(C+"\\logins.txt", "rw");
            for(int i=0;i<ln;i+=6){System.out.println("count "+i);
               firstname= raf.readLine().substring(11);
               lastname=raf.readLine().substring(10);
               String forUser = raf.readLine().substring(9);
               String forpswd = raf.readLine().substring(9);
               
                if(usr.equals(forUser) && pswd.equals(forpswd)){
                    JOptionPane.showMessageDialog(null, "password matched");
                    acno=raf.readLine().substring(12);
                    bal=raf.readLine().substring(16);
                    sendata(usr);
                    q=true;
                    frontScreen s=new frontScreen();
                    s.setVisible(true);
                    dispose();
                   
                    
                    break;
                }
           
                for(int k=1;k<=3;k++){
                    raf.readLine();
                }
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    public void sendata(String usr){
        acc+=usr;
    }
    void countLines(){
        try {
            ln=0;
            RandomAccessFile raf = new RandomAccessFile(C+"\\logins.txt", "rw");
            for(int i=0;raf.readLine()!=null;i++){
                ln++;
            }
            System.out.println("number of lines:"+ln);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel8 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        tfusr = new javax.swing.JTextField();
        tfpswd = new javax.swing.JTextField();
        tfmail = new javax.swing.JTextField();
        tffirst = new javax.swing.JTextField();
        tflast = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tfusr1 = new javax.swing.JTextField();
        tfpswd1 = new javax.swing.JPasswordField();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel27 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton3 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton11 = new javax.swing.JButton();
        jTextField5 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 204, 51));
        setForeground(new java.awt.Color(0, 204, 51));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 640, 70));

        jPanel3.setBackground(new java.awt.Color(69, 115, 252));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/5556a3df-f424-42a7-8a6b-c9078205d8c6.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 70, 240, 160));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/Screenshot 2021-08-19 180634.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 180, 130));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 480));

        jTabbedPane1.addTab("tab3", jPanel3);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 36)); // NOI18N
        jLabel1.setText("Create Account");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 380, 45));

        jLabel2.setFont(new java.awt.Font("Bookman Old Style", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 255, 255));
        jLabel2.setText("Username:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 110, 120, 44));

        jLabel3.setFont(new java.awt.Font("Bookman Old Style", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 255, 255));
        jLabel3.setText("Password:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 210, 95, -1));

        jLabel4.setFont(new java.awt.Font("Bookman Old Style", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 255, 255));
        jLabel4.setText("Initial Balance:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 310, 160, -1));

        jLabel8.setFont(new java.awt.Font("Lucida Fax", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(204, 255, 255));
        jLabel8.setText("First Name:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 120, -1, 30));

        jLabel28.setFont(new java.awt.Font("Lucida Fax", 0, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(204, 255, 255));
        jLabel28.setText("Last Name:");
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 210, -1, -1));

        tfusr.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel1.add(tfusr, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 150, 230, 30));

        tfpswd.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel1.add(tfpswd, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 240, 220, 30));

        tfmail.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel1.add(tfmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 340, 310, 30));
        jPanel1.add(tffirst, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 180, 30));
        jPanel1.add(tflast, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, 180, 30));

        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setText("Register");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 400, 82, 38));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 470));

        jTabbedPane1.addTab("tab1", jPanel1);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Magneto", 0, 48)); // NOI18N
        jLabel5.setText("ATM Login");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 370, 70));

        jLabel6.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 255, 255));
        jLabel6.setText("Password");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 200, 98, -1));

        jLabel7.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 255, 255));
        jLabel7.setText("Username");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 120, 97, 35));

        tfusr1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jPanel2.add(tfusr1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 360, 30));

        tfpswd1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jPanel2.add(tfpswd1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 360, 30));

        jButton7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton7.setText("clear all");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 310, -1, 40));

        jButton8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton8.setText("Login");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 80, 40));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 470));

        jTabbedPane1.addTab("tab2", jPanel2);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 417, 374));

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel4.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 480));

        jTabbedPane1.addTab("tab4", jPanel4);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 422, 346));

        jButton3.setBackground(new java.awt.Color(255, 0, 255));
        jButton3.setFont(new java.awt.Font("SimSun-ExtB", 1, 24)); // NOI18N
        jButton3.setText("<<");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel5.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 60, 40));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel5.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 480));

        jTabbedPane1.addTab("tab5", jPanel5);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 255, 255));
        jLabel9.setText("Enter New Password:");
        jPanel6.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, -1, -1));
        jPanel6.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 200, 240, -1));

        jButton2.setFont(new java.awt.Font("Gill Sans MT", 1, 11)); // NOI18N
        jButton2.setText("Change Password");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 250, 150, -1));

        jLabel25.setFont(new java.awt.Font("Wide Latin", 0, 27)); // NOI18N
        jLabel25.setText("SOA Bank");
        jPanel6.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 250, 60));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel6.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, -10, 680, 490));

        jTabbedPane1.addTab("tab6", jPanel6);

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(204, 255, 255));
        jLabel15.setText("Enter Withdrawal Balance:");
        jPanel9.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 180, 20));
        jPanel9.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 312, 27));

        jButton9.setBackground(new java.awt.Color(255, 255, 255));
        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 51, 51));
        jButton9.setText("Collect");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 120, 40));

        jLabel23.setFont(new java.awt.Font("Wide Latin", 0, 27)); // NOI18N
        jLabel23.setText("SOA Bank");
        jPanel9.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, 250, 60));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel9.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 480));

        jTabbedPane1.addTab("tab6", jPanel9);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("Lucida Fax", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(204, 255, 255));
        jLabel16.setText("Enter The Cash Amount:");
        jPanel10.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, -1, -1));
        jPanel10.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 160, 312, 27));

        jButton10.setFont(new java.awt.Font("Perpetua Titling MT", 1, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 0, 102));
        jButton10.setText("Deposit");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 240, 107, 37));

        jLabel21.setFont(new java.awt.Font("Wide Latin", 0, 27)); // NOI18N
        jLabel21.setText("SOA Bank");
        jPanel10.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 250, 60));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel10.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 470));

        jTabbedPane1.addTab("tab6", jPanel10);

        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(204, 255, 255));
        jLabel17.setText("Enter The Amount:");
        jPanel11.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 130, 20));
        jPanel11.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, 312, 27));

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 0, 51));
        jButton11.setText("Transfer");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 300, 110, 40));
        jPanel11.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, 312, 28));

        jLabel22.setFont(new java.awt.Font("Wide Latin", 0, 27)); // NOI18N
        jLabel22.setText("SOA Bank");
        jPanel11.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 30, 250, 60));

        jLabel18.setFont(new java.awt.Font("Lucida Fax", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(204, 255, 255));
        jLabel18.setText("Enter The Receiver's Account Number:");
        jPanel11.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 120, 260, 30));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradient (7).png"))); // NOI18N
        jPanel11.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 470));

        jTabbedPane1.addTab("tab6", jPanel11);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 640, 490));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/atm/gradienta-bKESVqfxass-unsplash (1).png"))); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 651, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 620));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
createFolder(); 
readFile();
countLines();
addData(tffirst.getText(),tflast.getText(),tfusr.getText(),tfpswd.getText(),tfmail.getText());  
tffirst.setText("");
tflast.setText("");
tfusr.setText("");     
tfpswd.setText("");
tfmail.setText("");
JOptionPane.showMessageDialog(null,"Data Registered");  
jTabbedPane1.setSelectedIndex(0); 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        jTabbedPane1.setSelectedIndex(1);   
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
tfusr1.setText("");     
tfpswd1.setText("");
   
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
createFolder(); 
readFile();
countLines();
logic(tfusr1.getText(), tfpswd1.getText());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
jTabbedPane1.setSelectedIndex(2);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       createFolder(); 
       readFile();
       countLines();
        String pswdnew=jTextField1.getText();
        
    try {
            RandomAccessFile raf = new RandomAccessFile(C+"\\logins.txt", "rwd");
           

            for(int i=0;i<ln;i+=6){System.out.println("count "+i);
            
               raf.readLine();
               raf.readLine();
               String forUser =raf.readLine().substring(9);
               if(acc.equals(forUser)){
               raf.writeBytes("Password:"+pswdnew);
               
                 
                    JOptionPane.showMessageDialog(null,"Password Changed");

                    raf.readLine();
                    raf.readLine();
                    frontScreen s=new frontScreen();
                    s.setVisible(true);
                    dispose();
                   
                    
                    break;
                }
                
                // if you are using user & passwword without email
                // then dont forget to replace  k<=2 with k=2 below
                for(int k=1;k<=4;k++){
                    raf.readLine();
                }
            
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        }
        

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        int minus=Integer.parseInt(jTextField2.getText());
        int actual=Integer.parseInt(bal);
        if(actual>minus){
           prevbal=prevbal+bal;
        bal=Integer.toString(actual-minus);
        change=change+Integer.toString(actual-Integer.parseInt(bal));
        editbaldata();
        frontScreen s=new frontScreen();
                    s.dispose();
        progress22 pro2= new progress22();
        pro2.setVisible(true);
        dispose();
       
        }
        else if(minus>actual){
            JOptionPane.showMessageDialog(null,"Insufficient Balance !!");
             frontScreen s=new frontScreen();
                    s.setVisible(true);
            dispose();
            
        }
         
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
       int add=Integer.parseInt(jTextField3.getText());
       int  actual=Integer.parseInt(bal);
       prevbal=prevbal+bal;
        bal=Integer.toString(actual+add);
        change=change+Integer.toString(Integer.parseInt(bal)-actual);
        editbaldata();
        progress2 pro=new progress2();
        pro.setVisible(true);
        dispose();
        
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        int minus=Integer.parseInt(jTextField4.getText());
       int  actual=Integer.parseInt(bal);
        if(actual>minus){
            prevbal=prevbal+bal;
        bal=Integer.toString(actual-minus);
        change=change+Integer.toString(Integer.parseInt(bal)-actual);
        editbaldata();
        progress21 pro1=new progress21();
        pro1.setVisible(true);
        dispose();
        
        }
        else if(minus>actual){
            JOptionPane.showMessageDialog(null,"Insufficient Balance !!");
             frontScreen s=new frontScreen();
                    s.setVisible(true);
            dispose();
            
         }        
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      frontScreen s=new frontScreen();
                    s.setVisible(true);
                    dispose();
    }//GEN-LAST:event_jButton3ActionPerformed
public void accdetails(){
    jTabbedPane1.setSelectedIndex(3);
     int refs= 1325 + (int) (Math.random()*4238);
    Calendar timer = Calendar.getInstance();
        timer.getTime();
        SimpleDateFormat tTime = new SimpleDateFormat("HH:mm:ss");
        tTime.format(timer.getTime());
        SimpleDateFormat Tdate = new SimpleDateFormat("dd-MMM-yyyy");
        Tdate.format(timer.getTime());

        //========================================================================jtxtReceipt
        jTextArea1.append("\t ATM Management Systems\n" +
            "Reference:\t\t\t" +refs+  
            "\n===========================================\t " +
            "\nAccount Holder Name:\t\t"+firstname+" "+lastname+
            "\nAccount Number:\t\t "+acno+ 
            "\nPrevious Balance:\t\t"+" $"+prevbal+ 
            "\nChange:\t\t\t " + "$"+change+ 
            "\nTotal Balance:\t\t\t " + "$"+ bal+ 
            "\nBranch:\t\t\t " +"Bhubaneswar" +
            "\nName Of Bank:\t\t\t " +"SOA Bank" +

            "\n===========================================\t " +
            "\nDate: " + Tdate.format(timer.getTime()) +
            "\t\tTime: " + tTime.format(timer.getTime()) +
            "\n\n\t\tThank you\n" );
}
public void showbalance(){
    jTabbedPane1.setSelectedIndex(4);
     int refs= 1325 + (int) (Math.random()*4238);
Calendar timer = Calendar.getInstance();
        timer.getTime();
SimpleDateFormat tTime = new SimpleDateFormat("HH:mm:ss");
        tTime.format(timer.getTime());
        SimpleDateFormat Tdate = new SimpleDateFormat("dd-MMM-yyyy");
        Tdate.format(timer.getTime());

        //========================================================================jtxtReceipt
        jTextArea2.append("\t ATM Management Systems\n" +
            "Reference:\t\t\t" + refs+ 
            "\n===========================================\t " +
            "\nAccount Holder Name:\t\t"+" "+firstname+" "+lastname+
            "\nAccount Number:\t\t "+acno+ 
            "\nAvailable Balance:\t\t" + "$" +bal+ 
            "\nBranch:\t\t\t " + "Bhubaneswar"+
            "\nName Of Bank:\t\t\t " +"SOA Bank"+ 

            "\n===========================================\t " +
            "\nDate: " + Tdate.format(timer.getTime()) +
            "\t\tTime: " + tTime.format(timer.getTime()) +
            "\n\n\t\tThank you\n" );

}
public void editbaldata(){
       createFolder(); 
       readFile();
       countLines();
     
        
    try {
            RandomAccessFile raf = new RandomAccessFile(C+"\\logins.txt", "rwd");
            for(int i=0;i<ln;i+=6){System.out.println("count "+i);
               raf.readLine();
               raf.readLine();
               String forUser = raf.readLine().substring(9);
               String forpswd = raf.readLine().substring(9);
               
                if(acc.equals(forUser)){
                    
                    acno=raf.readLine().substring(12);
                    raf.writeBytes("Initial Balance:"+bal);
                    
                    
                   dispose();
                    
                    break;
                }

                // if you are using user & passwword without email
                // then dont forget to replace  k<=2 with k=2 below
                for(int k=1;k<=3;k++){
                    raf.readLine();
                }
            }
           

        } catch (FileNotFoundException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(notepad.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}
public void changepswd(){
    jTabbedPane1.setSelectedIndex(5);}
public void editbal1(){
    jTabbedPane1.setSelectedIndex(6);
}
public void addbalance(){
    jTabbedPane1.setSelectedIndex(7);
}
public void editbal2(){
    jTabbedPane1.setSelectedIndex(8);
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(notepad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(notepad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(notepad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(notepad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new notepad().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField tffirst;
    private javax.swing.JTextField tflast;
    private javax.swing.JTextField tfmail;
    private javax.swing.JTextField tfpswd;
    private javax.swing.JPasswordField tfpswd1;
    private javax.swing.JTextField tfusr;
    private javax.swing.JTextField tfusr1;
    // End of variables declaration//GEN-END:variables
}